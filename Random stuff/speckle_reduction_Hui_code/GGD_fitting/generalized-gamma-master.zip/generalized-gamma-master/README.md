# Generalized gamma distribution in Matlab
![Probability density function](GeneralizedGamma.jpg)